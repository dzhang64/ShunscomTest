//
// Created by Administrator on 2024/11/25 0025.
//

#ifndef SHUNSCOMTEST_NUMBERHELP_H
#define SHUNSCOMTEST_NUMBERHELP_H
#endif //SHUNSCOMTEST_NUMBERHELP_H
#include <stdint.h>

namespace ShunscomUtils{
    bool containsValue(uint8_t value, const uint8_t* array, size_t length);
}



